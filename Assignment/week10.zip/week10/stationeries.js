export default [
    { id: 1, name: "Pencil", stock: 30, price: 5, srcimg: "https://i.ibb.co/DptRh0j/Pngtree-vector-pencil-icon-3773618.png"},
    { id: 2, name: "Pen", stock: 60, price: 10, srcimg: "https://i.ibb.co/MCdtx02/Pngtree-vector-pen-icon-3994601.png"},
    { id: 3, name: "Notebook", stock: 10, price: 15, srcimg: "https://i.ibb.co/v3JZ7rV/Pngtree-spiral-notebook-icon-3728102.png" },
    { id: 4, name: "Eraser", stock: 20, price: 5, srcimg: "https://i.ibb.co/x6prFzS/Pngtree-white-office-eraser-4523059.png" },
    { id: 5, name: "Paint brush", stock: 25, price: 20, srcimg: "https://i.ibb.co/yFVB2V2/Pngtree-paint-brush-icon-cartoon-style-5166284.png" },
    { id: 6, name: "ruler", stock: 30, price: 12, srcimg: "https://i.ibb.co/h297NWz/Pngtree-ruler-4359175.png"},
];
// เก็บ product ไว้ใน array
// export ให้ไฟล์ productList.js