import {products} from './product.js';

const button = document.querySelector('#search');
const searchbar = document.querySelector('#searchbar');
const feed = document.querySelector('#feed');
const opal = document.querySelector('#active');
let item =[];
let index = 0;
let toggle = false;
button.addEventListener("click" , ()=> {
    toggle = !toggle;
    if(toggle){
        searchbar.innerHTML = `<input type = 'text' placeholder="Search..." id="searchValue" class="form-control">` 
        let searchValue = document.querySelector('#searchValue');
        searchValue.addEventListener('keyup' , () =>{
            let value = new RegExp(searchValue.value , 'i');
            let product1 = [];
            products.map((p) => {
                if (p.name.match(value) != null) {
                    product1.push(p);
                }
            })
            console.log(product1);
            item = product1;
        } 
        )
    }else
        searchbar.innerHTML = '';
})

opal.addEventListener("click" , ()=>{
    showProduct(item);
})

function showProduct(list){
    for(let pd of list){
        const img = document.createElement('img');
        img.setAttribute('src' , `${pd.img}`)
        feed.appendChild(img);
    }
}




